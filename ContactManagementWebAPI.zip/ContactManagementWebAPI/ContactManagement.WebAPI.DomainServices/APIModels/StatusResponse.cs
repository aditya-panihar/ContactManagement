﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace ContactManagement.WebAPI.DomainServices.APIModels
{
    [DataContract]
    public class StatusResponse
    {
        [DataMember(Name = "Code")]
        public int Code { get; set; }

        [DataMember(Name = "Information")]
        public string Information { get; set; }
    }
}
