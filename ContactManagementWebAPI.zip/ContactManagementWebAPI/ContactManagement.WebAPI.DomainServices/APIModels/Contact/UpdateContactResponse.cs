﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;

namespace ContactManagement.WebAPI.DomainServices.APIModels.Contact
{
    [DataContract]
    public class UpdateContactResponse
    {
        [DataMember(Name = "StatusResponse")]
        public StatusResponse StatusResponse { get; set; }

        public UpdateContactResponse()
        {
            this.StatusResponse = new StatusResponse();
        }
    }
}
