﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;

namespace ContactManagement.WebAPI.DomainServices.APIModels.Contact
{
    [DataContract]
    public class DeleteContactResponse
    {
        [DataMember(Name = "StatusResponse")]
        public StatusResponse StatusResponse { get; set; }

        public DeleteContactResponse()
        {
            this.StatusResponse = new StatusResponse();
        }
    }
}
