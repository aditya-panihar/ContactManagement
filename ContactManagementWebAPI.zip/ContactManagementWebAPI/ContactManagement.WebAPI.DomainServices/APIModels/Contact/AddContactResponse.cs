﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace ContactManagement.WebAPI.DomainServices.APIModels.Contact
{
    [DataContract]
    public class AddContactResponse
    {
        [DataMember(Name = "StatusResponse")]
        public StatusResponse StatusResponse { get; set; }

        public AddContactResponse()
        {
            this.StatusResponse = new StatusResponse();
        }
    }
}
