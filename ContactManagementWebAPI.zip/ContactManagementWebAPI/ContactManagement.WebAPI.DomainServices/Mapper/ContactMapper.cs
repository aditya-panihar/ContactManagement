﻿using ContactManagement.WebAPI.Domain.Models;
using ContactManagement.WebAPI.DomainServices.APIModels.Contact;
using ContactManagement.WebAPI.DomainServices.Interfaces.Mapper;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ContactManagement.WebAPI.DomainServices.Mapper
{
    public class ContactMapper : IContactMapper
    {
        public Task<List<ContactsResponse>> Map(IEnumerable<Contact> lstContacts)
        {
            List<ContactsResponse> lstResponse = new List<ContactsResponse>();

            foreach (var item in lstContacts)
            {
                lstResponse.Add(new ContactsResponse
                {
                    ContactId = item.ContactId,
                    FirstName = item.FirstName,
                    LastName = item.LastName,
                    Email = item.Email,
                    PhoneNumber = item.PhoneNumber,
                    Status = item.Status,
                    CreatedDateTime = item.CreatedDateTime,
                    ModifiedDateTime = item.ModifiedDateTime
                });
            }

            return Task.FromResult(lstResponse);
        }
    }
}
