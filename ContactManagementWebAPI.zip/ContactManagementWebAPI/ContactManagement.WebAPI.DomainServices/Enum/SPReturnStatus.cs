﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ContactManagement.WebAPI.DomainServices.Enum
{
    public enum SPReturnStatus
    {
        Error = 0,
        Success = 1,
        EmailExists = 2,
        ContactNotExists = 3
    }
}
