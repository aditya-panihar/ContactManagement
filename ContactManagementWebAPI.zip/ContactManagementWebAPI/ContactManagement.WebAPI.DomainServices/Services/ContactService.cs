﻿using ContactManagement.WebAPI.Domain.Models;
using ContactManagement.WebAPI.DomainServices.APIModels.Contact;
using ContactManagement.WebAPI.DomainServices.Enum;
using ContactManagement.WebAPI.DomainServices.Extensions;
using ContactManagement.WebAPI.DomainServices.Interfaces.Repositories;
using ContactManagement.WebAPI.DomainServices.Interfaces.Services;
using ContactManagement.WebAPI.DomainServices.Interfaces.Mapper;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ContactManagement.WebAPI.DomainServices.Services
{
    public class ContactService : IContactService
    {
        private readonly IContactRepository _contactRepository;
        private readonly IContactMapper _contactMapper;
        public ContactService(IContactRepository contactRepository, IContactMapper contactMapper)
        {
            _contactRepository = contactRepository;
            _contactMapper = contactMapper;
        }

        public async Task<AddContactResponse> SaveContactAsync(AddContactRequest contactRequest)
        {
            AddContactResponse addResp = new AddContactResponse();

            Contact objContact = new Contact();
            objContact.CopyPropertiesFrom(contactRequest);

            int code = await _contactRepository.InsertContactAsync(objContact);
            SPReturnStatus statusCode = (SPReturnStatus)code;

            switch (statusCode)
            {
                case SPReturnStatus.Error:
                    addResp.StatusResponse.Code = (int)SPReturnStatus.Error;
                    addResp.StatusResponse.Information = SPReturnStatus.Error.ToString();
                    break;
                case SPReturnStatus.Success:
                    addResp.StatusResponse.Code = (int)SPReturnStatus.Success;
                    addResp.StatusResponse.Information = SPReturnStatus.Success.ToString();
                    break;
                case SPReturnStatus.EmailExists:
                    addResp.StatusResponse.Code = (int)SPReturnStatus.EmailExists;
                    addResp.StatusResponse.Information = SPReturnStatus.EmailExists.ToString();
                    break;
            }

            return addResp;
        }

        public async Task<List<ContactsResponse>> GetContactsAsync()
        {
            List<ContactsResponse> lstcontactsResponse = new List<ContactsResponse>();
            var lstContact = await _contactRepository.GetContactsAsync();

            lstcontactsResponse = await _contactMapper.Map(lstContact);

            return lstcontactsResponse;
        }

        public async Task<ContactsResponse> GetContactByIdAsync(int id)
        {
            ContactsResponse contactsResponse = new ContactsResponse();
            var contact = await _contactRepository.GetContactByIdAsync(id);

            contactsResponse.CopyPropertiesFrom(contact);

            return contactsResponse;
        }

        public async Task<UpdateContactResponse> UpdateContactAsync(UpdateContactRequest contactRequest)
        {
            UpdateContactResponse updResp = new UpdateContactResponse();

            Contact objContact = new Contact();
            objContact.CopyPropertiesFrom(contactRequest);

            int code = await _contactRepository.UpdateContactAsync(objContact);
            SPReturnStatus statusCode = (SPReturnStatus)code;

            switch (statusCode)
            {
                case SPReturnStatus.Error:
                    updResp.StatusResponse.Code = (int)SPReturnStatus.Error;
                    updResp.StatusResponse.Information = SPReturnStatus.Error.ToString();
                    break;
                case SPReturnStatus.Success:
                    updResp.StatusResponse.Code = (int)SPReturnStatus.Success;
                    updResp.StatusResponse.Information = SPReturnStatus.Success.ToString();
                    break;
                case SPReturnStatus.EmailExists:
                    updResp.StatusResponse.Code = (int)SPReturnStatus.EmailExists;
                    updResp.StatusResponse.Information = SPReturnStatus.EmailExists.ToString();
                    break;
            }

            return updResp;
        }

        public async Task<DeleteContactResponse> DeleteContactAsync(int id)
        {
            DeleteContactResponse deleteResp = new DeleteContactResponse();

            int code = await _contactRepository.DeleteContactAsync(id);
            SPReturnStatus statusCode = (SPReturnStatus)code;

            switch (statusCode)
            {
                case SPReturnStatus.Error:
                    deleteResp.StatusResponse.Code = (int)SPReturnStatus.Error;
                    deleteResp.StatusResponse.Information = SPReturnStatus.Error.ToString();
                    break;
                case SPReturnStatus.Success:
                    deleteResp.StatusResponse.Code = (int)SPReturnStatus.Success;
                    deleteResp.StatusResponse.Information = SPReturnStatus.Success.ToString();
                    break;
                case SPReturnStatus.ContactNotExists:
                    deleteResp.StatusResponse.Code = (int)SPReturnStatus.ContactNotExists;
                    deleteResp.StatusResponse.Information = SPReturnStatus.ContactNotExists.ToString();
                    break;
            }

            return deleteResp;
        }
    }
}
