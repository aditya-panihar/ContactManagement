﻿using ContactManagement.WebAPI.Domain.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ContactManagement.WebAPI.DomainServices.Interfaces.Repositories
{
    public interface IContactRepository
    {
        Task<IEnumerable<Contact>> GetContactsAsync();
        Task<Contact> GetContactByIdAsync(int id);
        Task<int> InsertContactAsync(Contact objContact);
        Task<int> UpdateContactAsync(Contact objContact);
        Task<int> DeleteContactAsync(int id);
    }
}
