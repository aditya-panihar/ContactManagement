﻿using ContactManagement.WebAPI.Domain.Models;
using ContactManagement.WebAPI.DomainServices.APIModels.Contact;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ContactManagement.WebAPI.DomainServices.Interfaces.Mapper
{
    public interface IContactMapper
    {
        Task<List<ContactsResponse>> Map(IEnumerable<Contact> lstContacts);
    }
}
