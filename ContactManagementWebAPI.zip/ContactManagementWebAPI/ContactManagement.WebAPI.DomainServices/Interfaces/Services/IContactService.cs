﻿using ContactManagement.WebAPI.DomainServices.APIModels.Contact;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ContactManagement.WebAPI.DomainServices.Interfaces.Services
{
    public interface IContactService
    {
        Task<AddContactResponse> SaveContactAsync(AddContactRequest contactRequest);
        Task<List<ContactsResponse>> GetContactsAsync();
        Task<ContactsResponse> GetContactByIdAsync(int id);
        Task<UpdateContactResponse> UpdateContactAsync(UpdateContactRequest contactRequest);
        Task<DeleteContactResponse> DeleteContactAsync(int id);
    }
}
