﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;

namespace ContactManagement.WebAPI.Infra.Persistence
{
    public class AppDb : IDisposable
    {
        public SqlConnection Connection { get; }

        public AppDb(string connectionString)
        {
            Connection = new SqlConnection(connectionString);
        }

        public void Dispose() => Connection.Dispose();
    }
}
