﻿using ContactManagement.WebAPI.Domain.Models;
using ContactManagement.WebAPI.DomainServices.Interfaces.Repositories;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;

namespace ContactManagement.WebAPI.Infra.Persistence.Repositories
{
    public class ContactRepository : IContactRepository
    {
        private AppDb Db { get; set; }

        public ContactRepository(AppDb db)
        {
            Db = db;
        }

        public async Task<int> InsertContactAsync(Contact objContact)
        {
            int returncode = 0;
            try
            {
                using (SqlCommand cmd = new SqlCommand("POSTContact", Db.Connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@FirstName", objContact.FirstName);
                    cmd.Parameters.AddWithValue("@LastName", objContact.LastName);
                    cmd.Parameters.AddWithValue("@Email", objContact.Email);
                    cmd.Parameters.AddWithValue("@PhoneNumber", objContact.PhoneNumber);
                    cmd.Parameters.AddWithValue("@Status", objContact.Status);

                    cmd.Parameters.Add(new SqlParameter("@ReturnCode", SqlDbType.TinyInt) { Value = returncode, Direction = ParameterDirection.Output });

                    await Db.Connection.OpenAsync();
                    await cmd.ExecuteNonQueryAsync();
                    var outparam = cmd.Parameters["@ReturnCode"].Value;
                    returncode = Convert.ToInt32(string.IsNullOrEmpty(Convert.ToString(outparam)) ? 0 : Convert.ToInt32(outparam));

                    Db.Connection.Close();
                    Db.Dispose();
                }

                return returncode;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Contact>> GetContactsAsync()
        {
            List<Contact> lstContact = new List<Contact>();

            try
            {
                using (SqlCommand cmd = new SqlCommand("GETContacts", Db.Connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    await Db.Connection.OpenAsync();
                    using (var reader = await cmd.ExecuteReaderAsync())
                    {

                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync())
                            {
                                lstContact.Add(new Contact
                                {
                                    ContactId = Convert.ToInt32(reader["ContactId"]),
                                    FirstName = Convert.ToString(reader["FirstName"]),
                                    LastName = Convert.ToString(reader["LastName"]),
                                    Email = Convert.ToString(reader["Email"]),
                                    PhoneNumber = Convert.ToString(reader["PhoneNumber"]),
                                    Status = Convert.ToBoolean(reader["Status"]),
                                    CreatedDateTime = Convert.ToDateTime(reader["CreatedDateTime"]),
                                    ModifiedDateTime = Convert.ToDateTime(reader["ModifiedDateTime"])                                    
                                });
                            }
                        }
                    }

                    Db.Connection.Close();
                    Db.Dispose();
                }

                return lstContact;

            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task<Contact> GetContactByIdAsync(int id)
        {
            Contact contact = null;

            try
            {
                using (SqlCommand cmd = new SqlCommand("GETContactById", Db.Connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ContactId", id);

                    await Db.Connection.OpenAsync();
                    using (var reader = await cmd.ExecuteReaderAsync())
                    {

                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync())
                            {
                                contact = new Contact
                                {
                                    ContactId = Convert.ToInt32(reader["ContactId"]),
                                    FirstName = Convert.ToString(reader["FirstName"]),
                                    LastName = Convert.ToString(reader["LastName"]),
                                    Email = Convert.ToString(reader["Email"]),
                                    PhoneNumber = Convert.ToString(reader["PhoneNumber"]),
                                    Status = Convert.ToBoolean(reader["Status"]),
                                    CreatedDateTime = Convert.ToDateTime(reader["CreatedDateTime"]),
                                    ModifiedDateTime = Convert.ToDateTime(reader["ModifiedDateTime"])
                                };
                            }
                        }
                    }

                    Db.Connection.Close();
                    Db.Dispose();
                }

                return contact;

            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task<int> UpdateContactAsync(Contact objContact)
        {
            int returncode = 0;
            try
            {
                using (SqlCommand cmd = new SqlCommand("PUTContact", Db.Connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ContactId", objContact.ContactId);
                    cmd.Parameters.AddWithValue("@FirstName", objContact.FirstName);
                    cmd.Parameters.AddWithValue("@LastName", objContact.LastName);
                    cmd.Parameters.AddWithValue("@Email", objContact.Email);
                    cmd.Parameters.AddWithValue("@PhoneNumber", objContact.PhoneNumber);
                    cmd.Parameters.AddWithValue("@Status", objContact.Status);

                    cmd.Parameters.Add(new SqlParameter("@ReturnCode", SqlDbType.TinyInt) { Value = returncode, Direction = ParameterDirection.Output });

                    await Db.Connection.OpenAsync();
                    await cmd.ExecuteNonQueryAsync();
                    var outparam = cmd.Parameters["@ReturnCode"].Value;
                    returncode = Convert.ToInt32(string.IsNullOrEmpty(Convert.ToString(outparam)) ? 0 : Convert.ToInt32(outparam));

                    Db.Connection.Close();
                    Db.Dispose();
                }

                return returncode;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<int> DeleteContactAsync(int id)
        {
            int returncode = 0;
            try
            {
                using (SqlCommand cmd = new SqlCommand("DELETEContact", Db.Connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ContactId", id);

                    cmd.Parameters.Add(new SqlParameter("@ReturnCode", SqlDbType.TinyInt) { Value = returncode, Direction = ParameterDirection.Output });

                    await Db.Connection.OpenAsync();
                    await cmd.ExecuteNonQueryAsync();
                    var outparam = cmd.Parameters["@ReturnCode"].Value;
                    returncode = Convert.ToInt32(string.IsNullOrEmpty(Convert.ToString(outparam)) ? 0 : Convert.ToInt32(outparam));

                    Db.Connection.Close();
                    Db.Dispose();
                }

                return returncode;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
