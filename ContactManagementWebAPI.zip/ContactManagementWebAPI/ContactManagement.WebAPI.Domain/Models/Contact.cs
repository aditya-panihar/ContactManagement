﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace ContactManagement.WebAPI.Domain.Models
{
    [DataContract]
    public class Contact
    {
        [DataMember(Name = "Id")]
        public int ContactId { get; set; }

        [DataMember(Name = "FirstName")]
        public string FirstName { get; set; }

        [DataMember(Name = "LastName")]
        public string LastName { get; set; }

        [DataMember(Name = "Email")]
        public string Email { get; set; }

        [DataMember(Name = "PhoneNumber")]
        public string PhoneNumber { get; set; }

        [DataMember(Name = "Status")]
        public bool Status { get; set; }

        [DataMember(Name = "CreatedDateTime")]
        public DateTime CreatedDateTime { get; set; }

        [DataMember(Name = "ModifiedDateTime")]
        public DateTime ModifiedDateTime { get; set; }

    }
}
